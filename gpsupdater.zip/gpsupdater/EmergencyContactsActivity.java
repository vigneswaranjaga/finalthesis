package com.example.gpsupdater;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.preference.PreferenceManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

public class EmergencyContactsActivity extends AppCompatActivity {
    ContactAdapter contactAdapter;
    FirebaseFirestore db;
    String key = "";
    @BindView(R.id.recyclerViewNotes)
    RecyclerView recyclerViewNotes;
    ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_emergency_contacts);
        ButterKnife.bind(this);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        recyclerViewNotes.setLayoutManager(new LinearLayoutManager(this));
        db = FirebaseFirestore.getInstance();

        progressDialog=new ProgressDialog(this);
        progressDialog.setMessage("Loading...");


        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);
        String sss = prefs.getString("signature", "null");
        getContacts();
        findViewById(R.id.fab).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Toast.makeText(EmergencyContactsActivity.this, sss, Toast.LENGTH_SHORT).show();
                showDialog();
            }
        });
    }

    private void getContacts() {
        progressDialog.show();
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);
        String sss = prefs.getString("signature", "null");
        db.collection("users")
                .document(sss)
                .get()
                .addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                        List<String> stringList = (List<String>) task.getResult().get("emergency");
                        contactAdapter = new ContactAdapter(stringList);
                        recyclerViewNotes.setAdapter(contactAdapter);
                        progressDialog.dismiss();
                    }
                }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                progressDialog.dismiss();
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        int id = item.getItemId();

        switch (id) {
            case android.R.id.home:
                onBackPressed();
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    public void showDialog() {
        final Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.add_note_dialog);
        dialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        final EditText editTextTitle = dialog.findViewById(R.id.editTextTitle);
        TextView textViewAdd = dialog.findViewById(R.id.textViewAdd);
        TextView textViewCancel = dialog.findViewById(R.id.textViewCancel);
        textViewAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String Title = editTextTitle.getText().toString();
                Date createdAt = Calendar.getInstance().getTime();
                dialog.dismiss();
                SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(EmergencyContactsActivity.this);
                String sss = prefs.getString("signature", "null");


                progressDialog.show();
                db.collection("users")
                        .document(sss)
                        .update("emergency", FieldValue.arrayUnion(Title))
                        .addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                Toast.makeText(EmergencyContactsActivity.this, "Added", Toast.LENGTH_SHORT).show();
                                progressDialog.dismiss();
                                getContacts();
                            }
                        }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {

                    }
                });


                // Toast.makeText(EmergencyContactsActivity.this, s, Toast.LENGTH_SHORT).show();
            }
        });
        textViewCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                // fab.show();
            }
        });

        dialog.show();

    }

}
