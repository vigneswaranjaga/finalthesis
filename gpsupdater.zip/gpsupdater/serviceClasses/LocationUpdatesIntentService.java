package com.example.gpsupdater.serviceClasses;

import android.app.IntentService;
import android.content.Intent;
import android.location.Location;
import android.util.Log;


import com.google.android.gms.location.LocationResult;

import org.json.JSONObject;

import java.util.List;
public class LocationUpdatesIntentService extends IntentService {
    public static final String ACTION_PROCESS_UPDATES =
            "com.ahzimat.gpstrackerlite.action" +
                    ".PROCESS_UPDATES";
    private static final String TAG = LocationUpdatesIntentService.class.getSimpleName();

    public LocationUpdatesIntentService() {
        super(TAG);
    }

    @Override
    protected void onHandleIntent(Intent intent) {
        if (intent != null) {
            final String action = intent.getAction();
            if (ACTION_PROCESS_UPDATES.equals(action)) {
                LocationResult result = LocationResult.extractResult(intent);
                if (result != null) {
                    List<Location> locations = result.getLocations();
                    LocationResultHelper locationResultHelper = new LocationResultHelper(this,
                            locations);
                    // Save the location data to SharedPreferences.
                    locationResultHelper.saveResults();
                    // Show notification with the location data.
                    locationResultHelper.showNotification();

                    Log.i(TAG, LocationResultHelper.getSavedLocationResult(this));

                    for(Location location:locations){
                        String deviceStatus="M";
                        String signalStrength="G";
                        int speed=(int) ((location.getSpeed()*3600)/1000);






                    }




                }
            }
        }
    }
}

