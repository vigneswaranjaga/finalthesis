package com.example.gpsupdater.serviceClasses;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.location.Location;
import android.os.Build;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.preference.PreferenceManager;


import com.google.android.gms.location.LocationResult;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.GeoPoint;

import org.json.JSONObject;

import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.example.gpsupdater.SettingsActivity.KEY_SIGNATURE;


public class LocationUpdatesBroadcastReceiver extends BroadcastReceiver {
    private static final String TAG = "LUBroadcastReceiver";

    public static final String ACTION_PROCESS_UPDATES =
            "com.google.android.gms.location.sample.backgroundlocationupdates.action" +
                    ".PROCESS_UPDATES";

    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    public void onReceive(Context context, Intent intent) {

        if (intent != null) {
            final String action = intent.getAction();
            if (ACTION_PROCESS_UPDATES.equals(action)) {
                LocationResult result = LocationResult.extractResult(intent);
                if (result != null) {
                    List<Location> locations = result.getLocations();
                    LocationResultHelper locationResultHelper = new LocationResultHelper(
                            context, locations);
                    locationResultHelper.saveResults();
                    //show Notification
                    locationResultHelper.showNotification();
                    Log.i(TAG, LocationResultHelper.getSavedLocationResult(context));
                    for(Location location:locations){
                        String deviceStatus="M";
                        String signalStrength="G";
                        int speed=(int) ((location.getSpeed()*3600)/1000);
                        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(context);
                        String data=prefs.getString("signature","null");
                      //String data=KEY_SIGNATURE;
                        GeoPoint geoPoint=new GeoPoint(location.getLatitude(),location.getLongitude());

                        try{

                            FirebaseFirestore db = FirebaseFirestore.getInstance();
                            if(!data.equals("null")){
                                db.collection("users")
                                        .document(data)
                                        .update("currentlocation",geoPoint)
                                        .addOnCompleteListener(new OnCompleteListener<Void>() {
                                            @Override
                                            public void onComplete(@NonNull Task<Void> task) {

                                            }
                                        }).addOnFailureListener(new OnFailureListener() {
                                    @Override
                                    public void onFailure(@NonNull Exception e) {

                                    }
                                });

                            }

                        }catch (Exception ee){

                            Toast.makeText(context, data+" Not a valid", Toast.LENGTH_SHORT).show();
                        }




                    }

                }
            }
        }

    }
}
