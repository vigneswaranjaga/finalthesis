package com.example.gpsupdater;

import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class ContactAdapter extends RecyclerView.Adapter {
    List<String> notes ;

    public ContactAdapter(List<String> stringList) {
        this.notes=stringList;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View row = inflater.inflate(R.layout.item_contact, parent, false);
        return new NoteHolder(row);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        NoteHolder noteHolder = (NoteHolder) holder;
        noteHolder.textViewContact.setText(notes.get(position));

    }

    @Override
    public int getItemCount() {
        try{
            return notes.size();
        }catch (NullPointerException ex){
            return 0;
        }

    }

    public class NoteHolder extends RecyclerView.ViewHolder {
        TextView textViewContact;
      

        public NoteHolder(View itemView) {
            super(itemView);
            textViewContact = itemView.findViewById(R.id.textViewContact);
        }
    }

    public void addNotes(List<String> notes) {
        this.notes = notes;
        notifyDataSetChanged();
    }
}
